package authapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Интерактивная капча-пазл 2×2 из 4 заранее нарезанных картинок.
 *
 * Файлы в resources/images/:
 *   piece1.png — ВЕРХНИЙ-ЛЕВЫЙ
 *   piece2.png — ВЕРХНИЙ-ПРАВЫЙ
 *   piece3.png — НИЖНИЙ-ЛЕВЫЙ
 *   piece4.png — НИЖНИЙ-ПРАВЫЙ
 *
 * Сборка: клик по двум ячейкам меняет их фрагменты местами.
 * Пазл собран, когда order[i] == i для всех i.
 */
public class PuzzlePanel extends JPanel {

    private static final int PIECES = 4;        // 2×2
    private static final int SIDE = 2;          // сторона сетки
    private static final int PIECE_SIZE = 120;  // размер фрагмента в пикселях

    private final ImageIcon[] images = new ImageIcon[PIECES]; // «эталонные» фрагменты
    private final JLabel[] slots = new JLabel[PIECES];        // ячейки на экране
    private final int[] order = new int[PIECES];              // какой фрагмент в какой ячейке
    private int selected = -1;                                // индекс выбранной ячейки

    public PuzzlePanel() {
        // 0, 0 — без отступов между фрагментами
        setLayout(new GridLayout(SIDE, SIDE, 0, 0));
        setPreferredSize(new Dimension(SIDE * PIECE_SIZE, SIDE * PIECE_SIZE));

        loadImages();
        createSlots();
        shuffle();
    }

    /** Загрузка 4 готовых картинок из classpath. */
    private void loadImages() {
        for (int i = 0; i < PIECES; i++) {
            String path = "/images/piece" + (i + 1) + ".png";
            java.net.URL url = getClass().getResource(path);
            if (url == null) {
                JOptionPane.showMessageDialog(null,
                        "Не найдена картинка " + path,
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            Image scaled = new ImageIcon(url).getImage()
                    .getScaledInstance(PIECE_SIZE, PIECE_SIZE, Image.SCALE_SMOOTH);
            images[i] = new ImageIcon(scaled);
        }
    }

    /**
     * Создаём 4 кликабельные ячейки.
     * Картинка рисуется на ВСЮ площадь ячейки (getWidth/getHeight),
     * а не центрируется как иконка — поэтому щелей не будет при любом размере окна.
     */
    private void createSlots() {
        for (int i = 0; i < PIECES; i++) {
            final int idx = i;

            JLabel slot = new JLabel() {
                @Override
                protected void paintComponent(Graphics g) {
                    // Рисуем фрагмент растянутым на всю ячейку
                    ImageIcon icon = (ImageIcon) getIcon();
                    if (icon != null) {
                        g.drawImage(icon.getImage(), 0, 0, getWidth(), getHeight(), this);
                    }
                    // Красная рамка выделения поверх картинки
                    if (selected == idx) {
                        g.setColor(Color.RED);
                        g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
                        g.drawRect(1, 1, getWidth() - 3, getHeight() - 3);
                    }
                }
            };
            slot.setPreferredSize(new Dimension(PIECE_SIZE, PIECE_SIZE));
            slot.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) { onSlotClick(idx); }
            });
            slots[i] = slot;
            add(slot);
        }
    }

    /** Клик: первый — выбор, второй — обмен. */
    private void onSlotClick(int idx) {
        if (selected == -1) {
            selected = idx;
        } else if (selected == idx) {
            selected = -1;
        } else {
            int tmp = order[selected];
            order[selected] = order[idx];
            order[idx] = tmp;
            selected = -1;
            render();
        }
        repaint();
    }

    /** Перерисовать иконки согласно массиву order. */
    private void render() {
        for (int i = 0; i < PIECES; i++) {
            slots[i].setIcon(images[order[i]]);
        }
        repaint();
    }

    /** Перемешать. Гарантируем, что не окажется уже собранным. */
    public void shuffle() {
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < PIECES; i++) list.add(i);
        do {
            Collections.shuffle(list);
        } while (isCorrectOrder(list));
        for (int i = 0; i < PIECES; i++) order[i] = list.get(i);
        selected = -1;
        render();
    }

    private boolean isCorrectOrder(List<Integer> list) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) != i) return false;
        }
        return true;
    }

    /** true — пазл собран правильно. */
    public boolean isSolved() {
        for (int i = 0; i < PIECES; i++) {
            if (order[i] != i) return false;
        }
        return true;
    }
}