package authapp;

/** Модель пользователя — просто хранит данные из таблицы users. */
public class User {
    public int id;
    public String login;
    public String password;
    public String role;
    public boolean blocked;
    public int failedAttempts;

    public User(int id, String login, String password, String role,
                boolean blocked, int failedAttempts) {
        this.id = id;
        this.login = login;
        this.password = password;
        this.role = role;
        this.blocked = blocked;
        this.failedAttempts = failedAttempts;
    }
}