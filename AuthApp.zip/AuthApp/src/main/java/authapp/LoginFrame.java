package authapp;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

/**
 * Форма авторизации. Содержит main(), с неё стартует приложение.
 * Логика блокировки: 3 подряд неудачные попытки (неверный пароль ИЛИ несобранный пазл)
 * → пользователь блокируется в БД.
 */
public class LoginFrame extends JFrame {

    private final JTextField loginField = new JTextField(15);
    private final JPasswordField passwordField = new JPasswordField(15);
    private final PuzzlePanel puzzle = new PuzzlePanel();

    public LoginFrame() {
        setTitle("Авторизация");
        setSize(420, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Поле «Логин»
        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Логин:"), gbc);
        gbc.gridx = 1;
        add(loginField, gbc);

        // Поле «Пароль»
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Пароль:"), gbc);
        gbc.gridx = 1;
        add(passwordField, gbc);

        // Подпись к пазлу
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(new JLabel("Соберите пазл (клик по двум фрагментам — обмен):"), gbc);

        // Пазл
        gbc.gridy = 3;
        add(puzzle, gbc);

        // Кнопка «Войти»
        gbc.gridy = 4;
        JButton loginButton = new JButton("Войти");
        add(loginButton, gbc);
        loginButton.addActionListener(e -> doLogin());

        // Enter в полях тоже запускает вход — удобство
        getRootPane().setDefaultButton(loginButton);
    }

    /** Основная логика авторизации. */
    private void doLogin() {
        String login = loginField.getText().trim();
        String password = new String(passwordField.getPassword());

        // 1. Обязательные поля
        if (login.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Поля «Логин» и «Пароль» обязательны для заполнения.",
                    "Предупреждение", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            User u = UserDAO.findByLogin(login);

            // 2. Если пользователь существует и заблокирован — сразу отказ
            if (u != null && u.blocked) {
                JOptionPane.showMessageDialog(this,
                        "Вы заблокированы. Обратитесь к администратору",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean puzzleOk = puzzle.isSolved();
            boolean passwordOk = (u != null) && u.password.equals(password);

            // 3. Успех — правильный пароль + собранный пазл
            if (puzzleOk && passwordOk) {
                UserDAO.resetFailed(u.id);
                JOptionPane.showMessageDialog(this,
                        "Вы успешно авторизовались",
                        "Информация", JOptionPane.INFORMATION_MESSAGE);
                dispose();
                openDesktop(u);
                return;
            }

            // 4. Ошибка — увеличиваем счётчик неудач
            if (u != null) UserDAO.incFailed(u);

            // Пазл перемешиваем, чтобы нельзя было переиспользовать сборку
            puzzle.shuffle();

            // 5. Проверяем: не заблокировали ли мы пользователя этой попыткой
            User after = UserDAO.findByLogin(login);
            if (after != null && after.blocked) {
                JOptionPane.showMessageDialog(this,
                        "Вы заблокированы. Обратитесь к администратору",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 6. Понятное сообщение об ошибке
            if (!puzzleOk) {
                JOptionPane.showMessageDialog(this,
                        "Пазл собран неверно. Соберите картинку заново.",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                        "Вы ввели неверный логин или пароль. "
                                + "Пожалуйста проверьте ещё раз введенные данные",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Ошибка базы данных: " + ex.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Открытие рабочего стола в зависимости от роли.
     * Для администратора — отдельное окно с таблицей.
     * Для обычного пользователя — просто приветствие (без лишнего класса).
     */
    private void openDesktop(User u) {
        if ("Администратор".equals(u.role)) {
            new AdminFrame().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null,
                    "Здравствуйте, " + u.login + "!\nВы вошли как «" + u.role + "».",
                    "Рабочий стол", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /** Точка входа. */
    public static void main(String[] args) {
        // Запуск UI в правильном потоке Swing
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}