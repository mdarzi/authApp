package authapp;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/** Рабочий стол администратора: таблица пользователей + добавление/изменение. */
public class AdminFrame extends JFrame {

    private final DefaultTableModel model;
    private final JTable table;

    public AdminFrame() {
        setTitle("Панель администратора");
        setSize(750, 420);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Таблица только для чтения
        model = new DefaultTableModel(
                new String[]{"ID", "Логин", "Пароль", "Роль", "Заблокирован"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);

        JPanel buttons = new JPanel();
        JButton addBtn = new JButton("Добавить");
        JButton editBtn = new JButton("Изменить / Разблокировать");
        JButton refreshBtn = new JButton("Обновить");
        buttons.add(addBtn);
        buttons.add(editBtn);
        buttons.add(refreshBtn);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addUser());
        editBtn.addActionListener(e -> editUser());
        refreshBtn.addActionListener(e -> loadUsers());

        loadUsers();
    }

    /** Перечитать список из БД. */
    private void loadUsers() {
        try {
            model.setRowCount(0);
            List<User> users = UserDAO.getAll();
            for (User u : users) {
                model.addRow(new Object[]{
                        u.id, u.login, u.password, u.role, u.blocked ? "Да" : "Нет"
                });
            }
        } catch (SQLException ex) {
            showError("Ошибка БД: " + ex.getMessage());
        }
    }

    /** Диалог добавления нового пользователя. */
    private void addUser() {
        JTextField loginF = new JTextField();
        JPasswordField passF = new JPasswordField();
        JComboBox<String> roleC = new JComboBox<>(new String[]{"Пользователь", "Администратор"});

        Object[] msg = {"Логин:", loginF, "Пароль:", passF, "Роль:", roleC};
        int r = JOptionPane.showConfirmDialog(this, msg,
                "Добавление пользователя", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;

        String login = loginF.getText().trim();
        String pass = new String(passF.getPassword());
        if (login.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Заполните все поля.", "Предупреждение", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            if (!UserDAO.addUser(login, pass, (String) roleC.getSelectedItem())) {
                JOptionPane.showMessageDialog(this,
                        "Пользователь с таким логином уже существует.",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                return;
            }
            loadUsers();
            JOptionPane.showMessageDialog(this,
                    "Пользователь добавлен.", "Информация", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            showError("Ошибка БД: " + ex.getMessage());
        }
    }

    /** Диалог редактирования выбранного пользователя. */
    private void editUser() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this,
                    "Выберите пользователя в таблице.",
                    "Предупреждение", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) model.getValueAt(row, 0);
        String login = (String) model.getValueAt(row, 1);
        String pass = (String) model.getValueAt(row, 2);
        String role = (String) model.getValueAt(row, 3);
        boolean blocked = "Да".equals(model.getValueAt(row, 4));

        JTextField loginF = new JTextField(login);
        JTextField passF = new JTextField(pass);
        JComboBox<String> roleC = new JComboBox<>(new String[]{"Пользователь", "Администратор"});
        roleC.setSelectedItem(role);
        JCheckBox blockC = new JCheckBox("Заблокирован", blocked);

        Object[] msg = {"Логин:", loginF, "Пароль:", passF, "Роль:", roleC, blockC};
        int r = JOptionPane.showConfirmDialog(this, msg,
                "Изменение пользователя", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;

        try {
            UserDAO.updateUser(id, loginF.getText().trim(), passF.getText(),
                    (String) roleC.getSelectedItem(), blockC.isSelected());
            loadUsers();
            JOptionPane.showMessageDialog(this,
                    "Данные обновлены.", "Информация", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            showError("Ошибка БД: " + ex.getMessage());
        }
    }

    /** Универсальный вывод ошибки БД. */
    private void showError(String text) {
        JOptionPane.showMessageDialog(this, text,
                "Ошибка", JOptionPane.ERROR_MESSAGE);
    }
}