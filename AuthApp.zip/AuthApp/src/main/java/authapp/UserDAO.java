package authapp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Все операции с таблицей users и подключение к БД.
 * Имя базы данных — auth_app (создаётся скриптом в MySQL Workbench).
 */
public class UserDAO {

    private static final String URL =
            "jdbc:mysql://localhost:3306/auth_app?useSSL=false"
                    + "&serverTimezone=UTC&characterEncoding=UTF-8&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";       // логин MySQL
    private static final String DB_PASSWORD = "root";   // пароль MySQL

    /** Единая точка подключения к БД. */
    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, DB_USER, DB_PASSWORD);
    }

    /** Поиск по логину. null — если не найден. */
    public static User findByLogin(String login) throws SQLException {
        String sql = "SELECT * FROM users WHERE login = ?";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, login);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return readUser(rs);
            }
        }
        return null;
    }

    /** Увеличить счётчик неудач. При достижении 3 — блокируем. */
    public static void incFailed(User u) throws SQLException {
        int next = u.failedAttempts + 1;
        boolean block = next >= 3;
        String sql = "UPDATE users SET failed_attempts = ?, blocked = ? WHERE id = ?";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, block ? 0 : next);
            ps.setBoolean(2, block);
            ps.setInt(3, u.id);
            ps.executeUpdate();
        }
    }

    /** Сброс счётчика при успешном входе. */
    public static void resetFailed(int id) throws SQLException {
        String sql = "UPDATE users SET failed_attempts = 0 WHERE id = ?";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /** Добавление. false — если логин уже занят. */
    public static boolean addUser(String login, String password, String role)
            throws SQLException {
        if (findByLogin(login) != null) return false;
        String sql = "INSERT INTO users (login, password, role) VALUES (?, ?, ?)";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, login);
            ps.setString(2, password);
            ps.setString(3, role);
            ps.executeUpdate();
        }
        return true;
    }

    /** Обновление данных (в т.ч. снятие блокировки). */
    public static void updateUser(int id, String login, String password,
                                  String role, boolean blocked) throws SQLException {
        String sql = "UPDATE users SET login=?, password=?, role=?, "
                + "blocked=?, failed_attempts=0 WHERE id=?";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, login);
            ps.setString(2, password);
            ps.setString(3, role);
            ps.setBoolean(4, blocked);
            ps.setInt(5, id);
            ps.executeUpdate();
        }
    }

    /** Список всех пользователей (для таблицы администратора). */
    public static List<User> getAll() throws SQLException {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(readUser(rs));
        }
        return list;
    }

    /** Вспомогательный метод: ResultSet → User (чтобы не дублировать код). */
    private static User readUser(ResultSet rs) throws SQLException {
        return new User(
                rs.getInt("id"),
                rs.getString("login"),
                rs.getString("password"),
                rs.getString("role"),
                rs.getBoolean("blocked"),
                rs.getInt("failed_attempts"));
    }
}